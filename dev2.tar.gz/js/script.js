/*
 * Open source under the BSD License. 
 * 
 * Copyright (c) 2008 George McGinley Smith
*/
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('h.i[\'E\']=h.i[\'y\'];h.F(h.i,{z:\'A\',y:9(x,t,b,c,d){6 h.i[h.i.z](x,t,b,c,d)},G:9(x,t,b,c,d){6 c*(t/=d)*t+b},A:9(x,t,b,c,d){6-c*(t/=d)*(t-2)+b},H:9(x,t,b,c,d){e((t/=d/2)<1)6 c/2*t*t+b;6-c/2*((--t)*(t-2)-1)+b},I:9(x,t,b,c,d){6 c*(t/=d)*t*t+b},J:9(x,t,b,c,d){6 c*((t=t/d-1)*t*t+1)+b},K:9(x,t,b,c,d){e((t/=d/2)<1)6 c/2*t*t*t+b;6 c/2*((t-=2)*t*t+2)+b},L:9(x,t,b,c,d){6 c*(t/=d)*t*t*t+b},M:9(x,t,b,c,d){6-c*((t=t/d-1)*t*t*t-1)+b},N:9(x,t,b,c,d){e((t/=d/2)<1)6 c/2*t*t*t*t+b;6-c/2*((t-=2)*t*t*t-2)+b},O:9(x,t,b,c,d){6 c*(t/=d)*t*t*t*t+b},P:9(x,t,b,c,d){6 c*((t=t/d-1)*t*t*t*t+1)+b},Q:9(x,t,b,c,d){e((t/=d/2)<1)6 c/2*t*t*t*t*t+b;6 c/2*((t-=2)*t*t*t*t+2)+b},R:9(x,t,b,c,d){6-c*8.B(t/d*(8.g/2))+c+b},S:9(x,t,b,c,d){6 c*8.n(t/d*(8.g/2))+b},T:9(x,t,b,c,d){6-c/2*(8.B(8.g*t/d)-1)+b},U:9(x,t,b,c,d){6(t==0)?b:c*8.j(2,10*(t/d-1))+b},V:9(x,t,b,c,d){6(t==d)?b+c:c*(-8.j(2,-10*t/d)+1)+b},W:9(x,t,b,c,d){e(t==0)6 b;e(t==d)6 b+c;e((t/=d/2)<1)6 c/2*8.j(2,10*(t-1))+b;6 c/2*(-8.j(2,-10*--t)+2)+b},X:9(x,t,b,c,d){6-c*(8.o(1-(t/=d)*t)-1)+b},Y:9(x,t,b,c,d){6 c*8.o(1-(t=t/d-1)*t)+b},Z:9(x,t,b,c,d){e((t/=d/2)<1)6-c/2*(8.o(1-t*t)-1)+b;6 c/2*(8.o(1-(t-=2)*t)+1)+b},11:9(x,t,b,c,d){f s=1.l;f p=0;f a=c;e(t==0)6 b;e((t/=d)==1)6 b+c;e(!p)p=d*.3;e(a<8.r(c)){a=c;f s=p/4}m f s=p/(2*8.g)*8.u(c/a);6-(a*8.j(2,10*(t-=1))*8.n((t*d-s)*(2*8.g)/p))+b},12:9(x,t,b,c,d){f s=1.l;f p=0;f a=c;e(t==0)6 b;e((t/=d)==1)6 b+c;e(!p)p=d*.3;e(a<8.r(c)){a=c;f s=p/4}m f s=p/(2*8.g)*8.u(c/a);6 a*8.j(2,-10*t)*8.n((t*d-s)*(2*8.g)/p)+c+b},13:9(x,t,b,c,d){f s=1.l;f p=0;f a=c;e(t==0)6 b;e((t/=d/2)==2)6 b+c;e(!p)p=d*(.3*1.5);e(a<8.r(c)){a=c;f s=p/4}m f s=p/(2*8.g)*8.u(c/a);e(t<1)6-.5*(a*8.j(2,10*(t-=1))*8.n((t*d-s)*(2*8.g)/p))+b;6 a*8.j(2,-10*(t-=1))*8.n((t*d-s)*(2*8.g)/p)*.5+c+b},14:9(x,t,b,c,d,s){e(s==v)s=1.l;6 c*(t/=d)*t*((s+1)*t-s)+b},15:9(x,t,b,c,d,s){e(s==v)s=1.l;6 c*((t=t/d-1)*t*((s+1)*t+s)+1)+b},16:9(x,t,b,c,d,s){e(s==v)s=1.l;e((t/=d/2)<1)6 c/2*(t*t*(((s*=(1.C))+1)*t-s))+b;6 c/2*((t-=2)*t*(((s*=(1.C))+1)*t+s)+2)+b},D:9(x,t,b,c,d){6 c-h.i.w(x,d-t,0,c,d)+b},w:9(x,t,b,c,d){e((t/=d)<(1/2.k)){6 c*(7.q*t*t)+b}m e(t<(2/2.k)){6 c*(7.q*(t-=(1.5/2.k))*t+.k)+b}m e(t<(2.5/2.k)){6 c*(7.q*(t-=(2.17/2.k))*t+.18)+b}m{6 c*(7.q*(t-=(2.19/2.k))*t+.1a)+b}},1b:9(x,t,b,c,d){e(t<d/2)6 h.i.D(x,t*2,0,c,d)*.5+b;6 h.i.w(x,t*2-d,0,c,d)*.5+c*.5+b}});',62,74,'||||||return||Math|function|||||if|var|PI|jQuery|easing|pow|75|70158|else|sin|sqrt||5625|abs|||asin|undefined|easeOutBounce||swing|def|easeOutQuad|cos|525|easeInBounce|jswing|extend|easeInQuad|easeInOutQuad|easeInCubic|easeOutCubic|easeInOutCubic|easeInQuart|easeOutQuart|easeInOutQuart|easeInQuint|easeOutQuint|easeInOutQuint|easeInSine|easeOutSine|easeInOutSine|easeInExpo|easeOutExpo|easeInOutExpo|easeInCirc|easeOutCirc|easeInOutCirc||easeInElastic|easeOutElastic|easeInOutElastic|easeInBack|easeOutBack|easeInOutBack|25|9375|625|984375|easeInOutBounce'.split('|'),0,{}));

var Froogaloop=function(){function d(a,b,c){c?(e[c]||(e[c]={}),e[c][a]=b):e[a]=b}function c(a){if(a.origin!=playerDomain)return!1;var b=JSON.parse(a.data);a=b.value;var c=b.data,d=d==""?null:b.player_id;b=d?e[d][b.event||b.method]:e[b.event||b.method];var f=[];if(!b)return!1;a!==void 0&&f.push(a);c&&f.push(c);d&&f.push(d);return f.length>0?b.apply(null,f):b.call()}function b(a,b,c){if(!c.contentWindow.postMessage)return!1;var d=c.getAttribute("src").split("?")[0];a=JSON.stringify({method:a,value:b});c.contentWindow.postMessage(a,d)}function a(b){return new a.fn.init(b)}var e={},f=!1;a.fn=a.prototype={playerDomain:"",element:null,init:function(a){typeof a==="string"&&(a=document.getElementById(a));this.element=a;return this},api:function(a,c){if(!this.element||!a)return!1;var e=this.element,f=e.id!=""?e.id:null,g=!c||!c.constructor||!c.call||!c.apply?c:null,i=c&&c.constructor&&c.call&&c.apply?c:null;i&&d(a,i,f);b(a,g,e);return this},addEvent:function(a,e){if(!this.element)return!1;var g=this.element;d(a,e,g.id!=""?g.id:null);a!="ready"&&b("addEventListener",a,g);if(f)return this;g=g.getAttribute("src").split("/");for(var l="",m=0,n=g.length;m<n;m++){if(m<3)l+=g[m];else break;m<2&&(l+="/")}playerDomain=l;window.addEventListener?window.addEventListener("message",c,!1):window.attachEvent("onmessage",c,!1);f=!0;return this},removeEvent:function(a){if(!this.element)return!1;var c=this.element,d;a:{if((d=c.id!=""?c.id:null)&&e[d]){if(!e[d][a]){d=!1;break a}e[d][a]=null}else{if(!e[a]){d=!1;break a}e[a]=null}d=!0}a!="ready"&&d&&b("removeEventListener",a,c)}};a.fn.init.prototype=a.fn;return window.Froogaloop=window.$f=a}();



/*
 * Motion Slider v1.0 - jQuery Image Slider
 * 
 * (c) Copyright Steven "cmsmasters" Masters
 * http://cmsmastrs.net/
 * For sale on ThemeForest.net
 */
(function(a){a.fn.cmsmsMotionSlider=function(b){var b=jQuery.extend({sliderWidth:1e3,sliderHeight:500,pauseOnHover:true,showControl:true,showNav:true,navThumbs:true,showArrows:true,showPause:true,showTimer:true,showLightbox:true,showCaptions:true,useCanvas:true},b);return this.each(function(){function bL(a,b,c,d){a.beginPath();a.moveTo(0,0);a.lineTo(b,0);a.lineTo(b,c);a.lineTo(0,c);a.closePath();a.fill();if(b<d-1){a.save();a.shadowOffsetX=1;a.shadowBlur=1;a.shadowColor="#333333";a.fillRect(b,0,1,N);a.restore()}}function bK(a,b,c){a.save();a.shadowOffsetX=0;a.shadowOffsetY=0;a.shadowBlur=2;a.shadowColor="#333333";a.fillStyle="#666666";bI(a,b,c);bJ(a,b,c);a.restore()}function bJ(a,b,c){a.beginPath();a.moveTo(1e3,1e3);a.lineTo(1e3,-1e3);a.lineTo(-1e3,-1e3);a.lineTo(-1e3,1e3);a.lineTo(1e3,1e3);a.moveTo(0,0);a.lineTo(b,0);a.lineTo(b,c);a.lineTo(0,c);a.closePath();a.fill()}function bI(a,b,c){a.beginPath();a.moveTo(0,0);a.lineTo(b,0);a.lineTo(b,c);a.lineTo(0,c);a.closePath();a.fill()}function bH(a,b){for(var c=0;c<a.length;c++){if(a[c]==b)a.splice(c,1)}}function bG(a){params=["in","none","out"];if(a)bH(params,a);return params[parseInt(Math.random()*params.length)]}function bF(a){params=["left","center","right"];if(a)bH(params,a);return params[parseInt(Math.random()*params.length)]}function bE(a){params=["top","center","bottom"];if(a)bH(params,a);return params[parseInt(Math.random()*params.length)]}function bD(){if(b.showPause){bc.show();bd.show();bk.parent().fadeOut(100,function(){bd.animate({left:"70px"},500);bc.animate({left:0},500,function(){be.parent().fadeIn(100)})})}else{bc.show();bd.show();bk.parent().fadeOut(100,function(){bd.animate({left:"70px"},500);bc.animate({left:0},500)})}}function bC(){if(b.showPause){be.parent().fadeOut(100,function(){bd.animate({left:"30px"},500);bc.animate({left:"41px"},500,function(){bk.parent().fadeIn(100,function(){bc.hide();bd.hide()})})})}else{bd.animate({left:"30px"},500);bc.animate({left:"41px"},500,function(){bk.parent().fadeIn(100,function(){bc.hide();bd.hide()})})}}function bB(){$invideo=false;$workSlider.find("li.active iframe").fadeOut(500,function(){bx(be);$workSlider.find("li.active canvas").css({display:"block"})});iframe=false}function bA(){var a=Q.height();var b=Q.parent().height();var c=parseInt(Q.css("margin-top").replace("-","").replace("px",""));if(c>0){c/b<1?Q.animate({marginTop:0},300):Q.animate({marginTop:"-"+parseInt(c-b)+"px"},300)}}function bz(){var a=Q.height();var b=Q.parent().height();var c=parseInt(Q.css("margin-top").replace("-","").replace("px",""));if(parseInt(a-c)>b){if(a/b<2){Q.animate({marginTop:parseInt(b-parseInt(a-c))+"px"},300)}else{parseInt(a-c)/b<2?Q.animate({marginTop:"-"+parseInt(a-b)+"px"},300):Q.animate({marginTop:"-"+parseInt(c+b)+"px"},300)}}}function by(){var a=Q.height();var b=Q.parent().height()+20;var c=parseInt(b/85);var d=parseInt(Q.css("margin-top").replace("-","").replace("px",""));var e=Q.find("li.active").position().top>0?Q.find("li.active").position().top+95:Q.find("li.active").position().top+75;if(e<d){if((d-e+75)/b<1){d+75>c*85?Q.animate({marginTop:"-"+parseInt(d-c*85)+"px"},300):bA()}else{Q.animate({marginTop:0},300)}}else if(e-d>b){if((e-d-95)/b>1){Q.animate({marginTop:"-"+parseInt(a-b+20)+"px"},300)}else{b+d+85<a?Q.animate({marginTop:"-"+parseInt(c*85+d)+"px"},300):bz()}}}function bx(a){if(a.hasClass("active")){a.removeClass("active");J=false}else{a.addClass("active");J=true}}function bw(){if(F||$infadein)return false;if(be.hasClass("active")){be.removeClass("active");J=false}countdown=0}function bv(){if(F||$infadein)return false;$prevIndex=$workSlider.find("li.active").index();$currentIndex=$prevIndex==0?parseInt(g-1):parseInt($prevIndex-1);if(be.hasClass("active")){be.removeClass("active");J=false}countdown=0;E=true}function bu(b){if(F||$infadein)return false;$prevIndex=$workSlider.find("li.active").index();$currentIndex=a(b).parent().index();if($prevIndex==$currentIndex)return false;if(be.hasClass("active")){be.removeClass("active");J=false}countdown=0;E=true}function bt(){if(a(".showHide a").parent().hasClass("hidden")){a(".showHide").removeClass("hidden");a(".showHide a").parent().parent().animate({right:0},500)}else{a(".showHide a").parent().parent().animate({right:"-140px"},500,function(){a(".showHide").addClass("hidden")})}}function bs(){if(J||countdown<0)return;br(M-parseInt(countdown/L));if(countdown===0)bp();countdown--}function br(a){if(bg){bg.clearRect(0,0,M,N);if(a<M){bK(bg,M,N);bL(bg,a,N,M)}}else{bj.css({backgroundPosition:"-"+Math.round(Math.round(10-10*(a/110))*11)+"px 0"})}}function bq(a,c,d,e,f,g,h){function A(){if(Math.abs(w-u)<=$widthPlus&&Math.abs(x-v)<=$heightPlus&&Math.abs(m-k)<=s&&Math.abs(n-l)<=t){clearInterval(C)}else{i.save();i.drawImage(y,-l,-k,u,v);i.restore();if(d=="in"){u+=$widthPlus;v+=$heightPlus}else{u-=$widthPlus;v-=$heightPlus}if($verDirection=="up"){if(d=="in"){g=="top"?k-=s:k+=s}else{k-=s}}else if($verDirection=="down"){if(d=="out"){e=="top"&&(g=="bottom"||g=="center")?k+=s:k-=s}else{k+=s}}else if($verDirection=="center"){d=="out"?k-=$heightPlus/2:k+=$heightPlus/2}else{d=="out"?k-=s:k+=s}if($horDirection=="left"){d=="in"?l+=t:l-=t}else if($horDirection=="right"){d=="out"?l-=t:l+=t}else if($horDirection=="center"){d=="out"?l-=$widthPlus/2:l+=$widthPlus/2}else{d=="out"?l-=t:l+=t}}}var i=document.getElementById("slideCanvas"+j).getContext("2d");var y=new Image;y.src=a.attr("src");switch(d){case"in":if(a.width()/b.sliderWidth<a.height()/b.sliderHeight){u=b.sliderWidth;o=0;v=a.width()>b.sliderWidth&&a.height()>b.sliderHeight?a.height()/parseFloat(a.width()/b.sliderWidth):a.height()*parseFloat(b.sliderWidth/a.width());p=v-b.sliderHeight}else if(a.width()/b.sliderWidth>a.height()/b.sliderHeight){u=a.width()>b.sliderWidth&&a.height()>b.sliderHeight?a.width()/parseFloat(a.height()/b.sliderHeight):a.width()*parseFloat(b.sliderHeight/a.height());o=u-b.sliderWidth;v=b.sliderHeight;p=0}else{u=b.sliderWidth;o=0;v=b.sliderHeight;p=0}if(a.width()>b.sliderWidth&&a.height()>b.sliderHeight){w=a.width();q=w-b.sliderWidth;x=a.height();r=x-b.sliderHeight}else{if(a.width()/b.sliderWidth<a.height()/b.sliderHeight){w=b.sliderWidth;q=0;x=a.height()*parseFloat(b.sliderWidth/a.width());r=x-b.sliderHeight}else if(a.width()/b.sliderWidth>a.height()/b.sliderHeight){w=a.width()*parseFloat(b.sliderHeight/a.height());q=w-b.sliderWidth;x=b.sliderHeight;r=0}else{w=b.sliderWidth;q=0;x=b.sliderHeight;r=0}}break;case"none":if(a.width()>b.sliderWidth&&a.height()>b.sliderHeight){w=u=a.width();q=o=u-b.sliderWidth;x=v=a.height();r=p=v-b.sliderHeight}else{if(a.width()/b.sliderWidth<a.height()/b.sliderHeight){w=u=b.sliderWidth;q=o=0;x=v=a.height()*parseFloat(b.sliderWidth/a.width());r=p=v-b.sliderHeight}else if(a.width()/b.sliderWidth>a.height()/b.sliderHeight){w=u=a.width()*parseFloat(b.sliderHeight/a.height());q=o=u-b.sliderWidth;x=v=b.sliderHeight;r=p=0}else{w=u=b.sliderWidth;q=o=0;x=v=b.sliderHeight;r=p=0}}break;case"out":if(a.width()>b.sliderWidth&&a.height()>b.sliderHeight){u=a.width();o=u-b.sliderWidth;v=a.height();p=v-b.sliderHeight}else{if(a.width()/b.sliderWidth<a.height()/b.sliderHeight){u=b.sliderWidth;o=0;v=a.height()*parseFloat(b.sliderWidth/a.width());p=v-b.sliderHeight}else if(a.width()/b.sliderWidth>a.height()/b.sliderHeight){u=a.width()*parseFloat(b.sliderHeight/a.height());o=u-b.sliderWidth;v=b.sliderHeight;p=0}else{u=b.sliderWidth;o=0;v=b.sliderHeight;p=0}}if(a.width()/b.sliderWidth<a.height()/b.sliderHeight){w=b.sliderWidth;q=0;x=a.width()>b.sliderWidth&&a.height()>b.sliderHeight?a.height()/parseFloat(a.width()/b.sliderWidth):a.height()*parseFloat(b.sliderWidth/a.width());r=x-b.sliderHeight}else if(a.width()/b.sliderWidth>a.height()/b.sliderHeight){w=a.width()>b.sliderWidth&&a.height()>b.sliderHeight?a.width()/parseFloat(a.height()/b.sliderHeight):a.width()*parseFloat(b.sliderHeight/a.height());q=w-b.sliderWidth;x=b.sliderHeight;r=0}else{w=b.sliderWidth;q=0;x=b.sliderHeight;r=0}break}switch(e){case"top":k=0;break;case"center":k=p/2;break;case"bottom":k=p;break}switch(f){case"left":l=0;break;case"center":l=o/2;break;case"right":l=o;break}switch(g){case"top":m=0;break;case"center":m=r/2;break;case"bottom":m=r;break}switch(h){case"left":n=0;break;case"center":n=q/2;break;case"right":n=q;break}if(e=="bottom"&&(g=="center"||g=="top")||e=="center"&&g=="top"){$verDirection="up"}else if(e=="top"&&(g=="center"||g=="bottom")||e=="center"&&g=="bottom"){$verDirection="down"}else if(e=="center"&&g=="center"){$verDirection="center"}else{$verDirection="none"}if(f=="right"&&(h=="center"||h=="left")||f=="center"&&h=="left"){$horDirection="left"}else if(f=="left"&&(h=="center"||h=="right")||f=="center"&&h=="right"){$horDirection="right"}else if(f=="center"&&h=="center"){$horDirection="center"}else{$horDirection="none"}clearInterval(C);$widthPlus=Math.abs(u-w)==0?0:parseFloat(Math.abs(u-w)/(25*c).toFixed(2));$heightPlus=Math.abs(v-x)==0?0:parseFloat(Math.abs(v-x)/(25*c).toFixed(2));s=Math.abs(k-m)==0?0:parseFloat(Math.abs(k-m)/(25*c).toFixed(2));t=Math.abs(l-n)==0?0:parseFloat(Math.abs(l-n)/(25*c).toFixed(2));var z=setInterval(function(){if(y.complete){clearInterval(z);i.drawImage(y,-l,-k,u,v);C=setInterval(A,40)}},50)}function bp(){function C(c){if(F||$infadein)return false;bC();if(be.is(":not(.active)"))bx(be);$invideo=true;if(d&&b.useCanvas){G=a(c).find("canvas:eq(0)").parent().attr("href")}else{G=a(c).find("img:eq(0)").parent().attr("href")}H=G.match(/^(http:\/\/)(www\.)?([^\/]+)(\.com)/i);if(H[3]=="youtube"){I=G.match(/^(http:\/\/)?(www\.)?youtube\.com\/(watch\?v=)?(v\/)?([^&]+)/i);var e=m?1:0;var f=n?0:1;if(a(c).find("#player"+j).attr("class")!="videoIframe"){var g=a('<div id="player'+j+'" class="videoIframe" />');a(c).append(g);var h=document.createElement("script");h.src="http://www.youtube.com/player_api";document.getElementById("player"+j).parentNode.insertBefore(h,document.getElementById("player"+j))}else{var g=a(c).find("#player"+j);a(g).find("iframe:eq(0)").css({display:"block"})}window.onYouTubePlayerAPIReady=function(){function c(){a.stopVideo();bB();bD();setTimeout(bw,1e3)}var a=new YT.Player("player"+j,{width:b.sliderWidth,height:b.sliderHeight,videoId:I[5],playerVars:{rel:0,showinfo:0,autoplay:1,autohide:1,fs:1,wmode:"opaque",hd:e,controls:f},events:{onStateChange:i}});bk.click(function(){if($invideo)c();return false})};function i(a){if(!l&&k&&a.data==YT.PlayerState.ENDED){a.target.stopVideo();bB();bD();setTimeout(bw,1e3)}else if(l&&a.data==YT.PlayerState.ENDED){a.target.seekTo(0)}}}else if(H[3]=="vimeo"){I=G.match(/^(http:\/\/)?(www\.)?vimeo\.com\/([^\/]+)/i);var o=l?1:0;var e=m?"high":"normal";if(a(c).find("#player"+j).attr("class")!="videoIframe"){var g=a('<iframe id="player'+j+'" class="videoIframe" src="http://player.vimeo.com/video/'+I[3]+"?title=0&byline=0&portrait=0&autoplay=1&autohide=1&wmode=opaque&api=1&player_id=player"+j+"&loop="+o+"&quality="+e+'" width="'+b.sliderWidth+'" height="'+b.sliderHeight+'" frameborder="0" webkitallowfullscreen />');a(c).append(g)}else{var g=a(c).find("#player"+j)}setTimeout(function(){function c(a){function e(){var a=document.getElementById("cmsmsMotionCloseButton");b(a,"click",function(a){if(a.target!=this||!$invideo)return false;c.api("seekTo",0);c.api("pause");bB();bD();setTimeout(bw,1e3)},false)}function d(){c.addEvent("finish",function(a){c.api("seekTo",0);c.api("pause");bB();bD();setTimeout(bw,1e3)})}var c=$f(a);if(!l&&k)d();e()}function b(a,b,c){if(a.addEventListener){a.addEventListener(b,c,false)}else{a.attachEvent("on"+b,c)}}var a=document.getElementById("player"+j);$f(a).addEvent("ready",c)},500)}if(d&&b.useCanvas){$workSlider.find("li.slide"+j+" canvas:eq(0)").css({display:"none"})}else{$workSlider.find("li.slide"+j+" img:eq(0)").css({display:"none"})}g.fadeIn(500);g=h=false}F=$infadein=true;br(0);if(E){i=$prevIndex?$prevIndex:$workSlider.find("li.active").index();j=$currentIndex;E=false}else{if($workSlider.find("li.active").is("li")){i=$workSlider.find("li.active").index();j=i==parseInt(g-1)?0:i+1}else{j=0}}var c=f.eq(j).find("img:eq(0)").parent().is("a");var e=f.eq(j).find("img:eq(0)").parent().is("a.video");var h=e?f.eq(j).find("img:eq(0)").parent().is("a.autoplay"):false;var k=e?f.eq(j).find("img:eq(0)").parent().is("a.autostop"):false;var l=e?f.eq(j).find("img:eq(0)").parent().is("a.loop"):false;var m=e?f.eq(j).find("img:eq(0)").parent().is("a.hd"):false;var n=e?f.eq(j).find("img:eq(0)").parent().is("a.hideControls"):false;var o=f.eq(j).find(".cmsmsSlideCaption").length>0?true:false;var p=f.eq(i).find(".cmsmsSlideCaption").length>0?true:false;if(o){var q=f.eq(j).find(".cmsmsSlideCaption").attr("data-width");var r=f.eq(j).find(".cmsmsSlideCaption").attr("data-top");var s=f.eq(j).find(".cmsmsSlideCaption").attr("data-left");q=q?q:bm;r=r?r:bn;s=s?s:bo}var t=f.eq(j).attr("data-pause");countdown=t?parseFloat(t)*18:countdown=90;L=parseFloat(countdown/M);var u=f.eq(j).attr("data-animation");u=u?u:30;var v=f.eq(j).attr("data-start");var w=v?v.split(/ /)[0]:bE();var x=v?v.split(/ /)[1]:bF();w=w!="top"&&w!="center"&&w!="bottom"?bE():w;x=x!="left"&&x!="center"&&x!="right"?bF():x;var y=f.eq(j).attr("data-finish");var z=y?y.split(/ /)[0]:bE();var A=y?y.split(/ /)[1]:bF();z=z!="top"&&z!="center"&&z!="bottom"?bE():z;A=A!="left"&&A!="center"&&A!="right"?bF():A;var B=f.eq(j).attr("data-zoom");if(w==z&&x==A){B=B?B:bG("none")}else{B=B?B:bG()}B=B!="in"&&B!="none"&&B!="out"?bG():B;if(d&&b.useCanvas)bq(f.eq(j).find("img:eq(0)"),parseFloat(u),B,w,x,z,A);Q.find("li.active").each(function(){a(this).removeClass("active")});Q.find("li:eq("+j+")").addClass("active");by();$workSlider.find("li.slide"+j).addClass("active").animate({opacity:1},500,function(){if(b.showCaptions&&o){$workSlider.find("li.slide"+j+" .cmsmsSlideCaption").css({width:q+"px"});$workSlider.find("li.slide"+j+" .cmsmsSlideCaptionContainer").css({width:0,display:"block"});var a=$workSlider.find("li.slide"+j+" .cmsmsSlideCaption").height();$workSlider.find("li.slide"+j+" .cmsmsSlideCaptionContainer").css({top:r+"px",left:s+"px",marginTop:a/2,marginLeft:q/2}).animate({width:q+"px",height:a+"px",marginTop:0,marginLeft:0,opacity:1},1e3,function(){$workSlider.find("li.slide"+j+" .cmsmsSlideCaption").animate({opacity:1,marginTop:0},500,function(){$infadein=false;if(h)C($workSlider.find("li.slide"+j))})})}else{$infadein=false;if(h)C($workSlider.find("li.slide"+j))}});if(i!="undefined"){$workSlider.find("li.slide"+i).animate({opacity:0},1e3,function(){a(this).removeClass("active");if(b.showCaptions&&p){$workSlider.find("li.slide"+i+" .cmsmsSlideCaptionContainer").css({display:"none",width:0,height:0,opacity:0,marginTop:"20px"});$workSlider.find("li.slide"+i+" .cmsmsSlideCaption").css({opacity:0})}$workSlider.find("li").not(".slide"+j).css({opacity:0})})}F=false;if(e){$workSlider.find("li.slide"+j).click(function(){C($workSlider.find("li.slide"+j));return false})}}var c=a(this);c.addClass("cmsmsMotionOldSlides");var d="getContext"in document.createElement("canvas");var e=c.wrap('<div class="cmsmsMotionSliderContainer" />').parent();e.css({width:b.sliderWidth+"px",height:b.sliderHeight+"px"});var f=c.find("li");var g=$count=f.length;var h=$hasVideo=$hasCaption=false;var i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C;var D=$currentIndex=$prevIndex=0;var E=false;var F=$infadein=$invideo=false;var G,H,I;var J=false;var K;var L=countdown=0;var M=110;var N=6;var O="";if(b.showControl){O+='<div class="cmsmsMotionControl">'+'<div class="showHide hidden"><a href="#">show/hide</a></div>'+'<div class="cmsmsMotionNavigation"><div class="navUp"><a href="#">up</a></div><ul><li><a href="#" class="active">1</a></li></ul><div class="navDown"><a href="#">down</a></div></div>'+'<div class="cmsmsMotionTime"></div>'+'<div class="cmsmsMotionPlayPause"><a href="#">pause</a></div>'+'<div class="cmsmsMotionArrows"><a class="cmsmsMotionPrev" href="#">prev</a><a class="cmsmsMotionNext" href="#">next</a></div>'+'<div class="cmsmsMotionClose"><a onClick="return false;" href="#" id="cmsmsMotionCloseButton">close</a></div>'+"</div>"}else{O+='<div class="cmsmsMotionClose"><a href="#">close</a></div>'}var P=O?a(O):false;c.after(P);P.height(b.sliderHeight);if(b.showControl){var Q=P.find(".cmsmsMotionNavigation ul");Q.parent().height(b.sliderHeight-195);Q.empty();if(b.showNav){for(var R=0;R<$count;R++){var S=f.eq(R).find("img").attr("src");var T=f.eq(R).attr("data-thumb")?f.eq(R).attr("data-thumb"):S;var U=R==0?' class="active"':"";var V=b.navThumbs?'<img src="'+T+'" width="110" height="65" alt="" />':parseInt(R+1);var W=f.eq(R).find("img").parent().is("a")?f.eq(R).find("img").parent().attr("href"):S;var X=b.navThumbs&&b.showLightbox?'<a href="'+W+'" class="navItemShow" rel="prettyPhoto[bgSlider]"> </a>':"";Q.append("<li"+U+'><a href="#" class="navItem">'+V+"</a>"+X+"</li>")}}else{Q.parent().hide()}var Y=P.find(".showHide a");var Z=Q.find("li a.navItem");var _=P.find(".navUp");var ba=P.find(".navDown");var bb=P.find(".cmsmsMotionArrows");var bc=bb.find(".cmsmsMotionPrev");var bd=bb.find(".cmsmsMotionNext");var be=P.find(".cmsmsMotionPlayPause a");var bf=P.find(".cmsmsMotionTime");if(!b.navThumbs)_.hide();if(!b.navThumbs)ba.hide();if(!b.showArrows)bb.hide();if(!b.showPause)be.parent().hide();bf.hide();if(d){var bg=a('<canvas width="'+M+'" height="'+N+'"></canvas>');bf.append(bg);bg=bg[0].getContext("2d");if(!bg)return;var bh=bg.createLinearGradient(0,N,0,0);bg.fillStyle="#ffffff"}else{var bi=a('<div class="cmsmsMotionTimeBg"><div class="cmsmsMotionTimeImage"></div></div>');bf.append(bi);var bj=bi.find(".cmsmsMotionTimeImage")}if(b.showTimer)bf.show()}var bk=P.find(".cmsmsMotionClose a");var bl='<ul class="cmsmsMotionSlides" />';c.after(bl);$workSlider=e.find(".cmsmsMotionSlides");$workSlider.css({width:b.sliderWidth+"px",height:b.sliderHeight+"px"});f.each(function(){var c=a(this);var e=c.find("img:eq(0)");h=e.parent().is("a")?true:false;$hasVideo=h&&e.parent().is("a.video")?true:false;$hasCaption=c.find(".cmsmsSlideCaption").length>0?true:false;$workSlider.append('<li class="slide'+D+'" />');if(d&&b.useCanvas){var f=document.createElement("canvas"),g=f.getContext("2d");f.width=b.sliderWidth;f.height=b.sliderHeight;$workSlider.find("li.slide"+D).append(f);h?$workSlider.find("li.slide"+D+" canvas").attr({id:"slideCanvas"+D}).wrap('<a href="'+e.parent().attr("href")+'" />'):$workSlider.find("li.slide"+D+" canvas").attr({id:"slideCanvas"+D});if($hasVideo)$workSlider.find("li.slide"+D+" a").append('<div class="cmsmsMotionVideoImage" />')}else{$workSlider.find("li.slide"+D).append(e.clone());var i=e.width();var j=e.height();var k=0;var l=0;if(i/b.sliderWidth<j/b.sliderHeight){j=b.sliderHeight*parseFloat(j/b.sliderHeight/(i/b.sliderWidth));i=b.sliderWidth;k=parseFloat((j-b.sliderHeight)/2)}else{i=b.sliderWidth*parseFloat(i/b.sliderWidth/(j/b.sliderHeight));j=b.sliderHeight;l=parseFloat((i-b.sliderWidth)/2)}$workSlider.find("li.slide"+D+" img:eq(0)").attr({id:"slideCanvas"+D}).css({width:i,height:j,margin:-k+" 0 0 -"+l});if(h)$workSlider.find("li.slide"+D+" img:eq(0)").wrap('<a href="'+e.parent().attr("href")+'" />');if($hasVideo)$workSlider.find("li.slide"+D+" a").append('<div class="cmsmsMotionVideoImage" />')}if($hasCaption){$workSlider.find("li.slide"+D).append(c.find(".cmsmsSlideCaption").clone());$workSlider.find("li.slide"+D+" .cmsmsSlideCaption").wrap('<div class="cmsmsSlideCaptionContainer" />')}D++});if(c.find(".cmsmsSlideCaption").length>0){var bm=a(".cmsmsSlideCaptionContainer").css("width").replace("px","");var bn=a(".cmsmsSlideCaptionContainer").css("top").replace("px","");var bo=a(".cmsmsSlideCaptionContainer").css("left").replace("px","")}bp();K=setInterval(bs,50);if(b.pauseOnHover){$workSlider.hover(function(){if(!$invideo)bx(be)},function(){if(!$invideo)bx(be)})}Y.click(function(){bt();return false});Z.click(function(){if(!$invideo)bu(this);return false});bc.click(function(){if(!$invideo)bv();return false});bd.click(function(){if(!$invideo)bw();return false});be.click(function(){if(!$invideo)bx(be);return false});ba.click(function(){bz();return false});_.click(function(){bA();return false})})}})(jQuery);



/*
 * Copyright (c) 2008 Joel Birch
 * 
 * Dual licensed under the MIT and GPL licenses:
 * 	http://www.opensource.org/licenses/mit-license.php
 * 	http://www.gnu.org/licenses/gpl.html
 */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}(';(2($){$.k.z=2(d){4 e=$.k.z,c=e.c,$N=$([\'<O 1k="\',c.P,\'"> &#1l;</O>\'].g(\'\')),q=2(){4 a=$(3),l=A(a);Q(l.B);a.R().1m().r()},C=2(){4 a=$(3),l=A(a),o=e.9;Q(l.B);l.B=1n(2(){o.D=($.1o(a[0],o.$m)>-1);a.r();t(o.$m.E&&a.F([\'h.\',o.j].g(\'\')).E<1){q.8(o.$m)}},o.S)},A=2(a){4 b=a.F([\'5.\',c.G,\':T\'].g(\'\'))[0];e.9=e.o[b.U];u b},V=2(a){a.v(c.W).1p($N.1q())};u 3.n(2(){4 s=3.U=e.o.E;4 o=$.X({},e.Y,d);o.$m=$(\'h.\'+o.H,3).1r(0,o.Z).n(2(){$(3).v([o.j,c.I].g(\' \')).1s(\'h:10(5)\').11(o.H)});e.o[s]=e.9=o;$(\'h:10(5)\',3)[($.k.12&&!o.13)?\'12\':\'1t\'](q,C).n(2(){t(o.14)V($(\'>a:T-1u\',3))}).w(\'.\'+c.I).r();4 b=$(\'a\',3);b.n(2(i){4 a=b.15(i).F(\'h\');b.15(i).1v(2(){q.8(a)}).1w(2(){C.8(a)})});o.16.8(3)}).n(2(){4 a=[c.G];t(e.9.J&&!($.x.17&&$.x.18<7))a.1x(c.y);$(3).v(a.g(\' \'))})};4 f=$.k.z;f.o=[];f.9={};f.K=2(){4 o=f.9;t($.x.17&&$.x.18>6&&o.J&&o.L.19!=1y)3.1z(f.c.y+\'-1a\')};f.c={I:\'p-1A\',G:\'p-1B-1C\',W:\'p-1D-5\',P:\'p-1E-1F\',y:\'p-1G\'};f.Y={j:\'1H\',H:\'1I\',Z:1,S:1J,L:{19:\'1K\'},1b:\'1L\',14:M,J:M,13:1c,16:2(){},1d:2(){},1e:2(){},1f:2(){}};$.k.X({r:2(){4 o=f.9,w=(o.D===M)?o.$m:\'\';o.D=1c;4 a=$([\'h.\',o.j].g(\'\'),3).1M(3).w(w).11(o.j).1g(\'>5\').1N().1h(\'1i\',\'1j\');o.1f.8(a);u 3},R:2(){4 o=f.9,1O=f.c.y+\'-1a\',$5=3.v(o.j).1g(\'>5:1j\').1h(\'1i\',\'1P\');f.K.8($5);o.1d.8($5);$5.1Q(o.L,o.1b,2(){f.K.8($5);o.1e.8($5)});u 3}})})(1R);',62,116,'||function|this|var|ul|||call|op|||||||join|li||hoverClass|fn|menu|path|each||sf|over|hideSuperfishUl||if|return|addClass|not|browser|shadowClass|superfish|getMenu|sfTimer|out|retainPath|length|parents|menuClass|pathClass|bcClass|dropShadows|IE7fix|animation|true|arrow|span|arrowClass|clearTimeout|showSuperfishUl|delay|first|serial|addArrow|anchorClass|extend|defaults|pathLevels|has|removeClass|hoverIntent|disableHI|autoArrows|eq|onInit|msie|version|opacity|off|speed|false|onBeforeShow|onShow|onHide|find|css|visibility|hidden|class|187|siblings|setTimeout|inArray|append|clone|slice|filter|hover|child|focus|blur|push|undefined|toggleClass|breadcrumb|js|enabled|with|sub|indicator|shadow|sfHover|overideThisToUse|800|show|normal|add|hide|sh|visible|animate|jQuery'.split('|'),0,{}));

eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}(';(3($){$.5.6=3(k){1 l=$.r({},$.5.6.s,k);G 7.8(3(){1 h=$(7);1 o=$.H?$.r({},l,h.I()):l;1 j=$(\'<t J="u-v">&#K;</t>\').2({\'L\':0,\'M\':\'N\',\'O\':\'-P\',\'4\':\'w\'}).Q(h).4();$(\'#u-v\').R();$m=h.S(\'x\');$m.8(3(i){1 c=$m.T(i);1 d=c.y();1 e=d.y(\'a\');1 f=d.2(\'z-A\',\'U\').2(\'n\');1 g=c.B(d).B(e).2({\'n\':\'V\',\'4\':\'w\'}).C().C()[0].W/j;g+=o.D;E(g>o.p){g=o.p}X E(g<o.q){g=o.q}g+=\'Y\';c.2(\'4\',g);d.2({\'n\':f,\'4\':\'Z%\',\'z-A\':\'10\'}).8(3(){1 a=$(\'>x\',7);1 b=a.2(\'F\')!==11?\'F\':\'12\';a.2(b,g)})})})};$.5.6.s={q:9,p:13,D:0}})(14);',62,67,'|var|css|function|width|fn|supersubs|this|each||||||||||||||ULs|float||maxWidth|minWidth|extend|defaults|li|menu|fontsize|auto|ul|children|white|space|add|end|extraWidth|if|left|return|meta|data|id|8212|padding|position|absolute|top|999em|appendTo|remove|find|eq|nowrap|none|clientWidth|else|em|100|normal|undefined|right|25|jQuery'.split('|'),0,{}));

eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(3($){$.I.J=3(f,g){4 c={u:7,o:K,v:0};c=$.w(c,g?{x:f,y:g}:f);4 d,8,9,l;4 h=3(a){d=a.z;8=a.A};4 i=3(a,b){b.2=q(b.2);5((B.C(9-d)+B.C(l-8))<c.u){$(b).D("r",h);b.m=1;n c.x.E(b,[a])}F{9=d;l=8;b.2=s(3(){i(a,b)},c.o)}};4 j=3(a,b){b.2=q(b.2);b.m=0;n c.y.E(b,[a])};4 k=3(e){4 p=(e.G=="t"?e.L:e.M)||e.N;O(p&&p!=6){P{p=p.Q}R(e){p=6}}5(p==6){n S}4 a=H.w({},e);4 b=6;5(b.2){b.2=q(b.2)}5(e.G=="t"){9=a.z;l=a.A;$(b).T("r",h);5(b.m!=1){b.2=s(3(){i(a,b)},c.o)}}F{$(b).D("r",h);5(b.m==1){b.2=s(3(){j(a,b)},c.v)}}};n 6.t(k).U(k)}})(H);',57,57,'||hoverIntent_t|function|var|if|this||cY|pX||||||||||||pY|hoverIntent_s|return|interval||clearTimeout|mousemove|setTimeout|mouseover|sensitivity|timeout|extend|over|out|pageX|pageY|Math|abs|unbind|apply|else|type|jQuery|fn|hoverIntent|100|fromElement|toElement|relatedTarget|while|try|parentNode|catch|false|bind|mouseout'.split('|'),0,{}));

jQuery(document).ready(function(){
	jQuery('ul#navigation').superfish({
		delay:500, 
		animation:{opacity:'show', height:'show'}, 
		speed:'fast', 
		autoArrows:false, 
		dropShadows:false 
	}); 
});



/*
 * jQuery Tools 1.2.5 Tooltip - UI essentials
 * NO COPYRIGHTS OR LICENSES. DO WHAT YOU LIKE.
 * Since: November 2008
 */
(function($){$.tools=$.tools||{version:'1.2.5'};$.tools.tooltip={conf:{effect:'toggle',fadeOutSpeed:"fast",predelay:0,delay:30,opacity:1,tip:0,position:['top','center'],offset:[0,0],relative:false,cancelDefault:true,events:{def:"mouseenter,mouseleave",input:"focus,blur",widget:"focus mouseenter,blur mouseleave",tooltip:"mouseenter,mouseleave"},layout:'<div/>',tipClass:'tooltip'},addEffect:function(a,b,c){g[a]=[b,c]}};var g={toggle:[function(a){var b=this.getConf(),tip=this.getTip(),o=b.opacity;if(o<1){tip.css({opacity:o})}tip.show();a.call()},function(a){this.getTip().hide();a.call()}],fade:[function(a){var b=this.getConf();this.getTip().fadeTo(b.fadeInSpeed,b.opacity,a)},function(a){this.getTip().fadeOut(this.getConf().fadeOutSpeed,a)}]};function getPosition(a,b,c){var d=c.relative?a.position().top:a.offset().top,left=c.relative?a.position().left:a.offset().left,pos=c.position[0];d-=b.outerHeight()-c.offset[0];left+=a.outerWidth()+c.offset[1];if(/iPad/i.test(navigator.userAgent)){d-=$(window).scrollTop()}var e=b.outerHeight()+a.outerHeight();if(pos=='center'){d+=e/2}if(pos=='bottom'){d+=e}pos=c.position[1];var f=b.outerWidth()+a.outerWidth();if(pos=='center'){left-=f/2}if(pos=='left'){left-=f}return{top:d,left:left}}function Tooltip(c,d){var f=this,fire=c.add(f),tip,timer=0,pretimer=0,title=c.attr("title"),tipAttr=c.attr("data-tooltip"),effect=g[d.effect],shown,isInput=c.is(":input"),isWidget=isInput&&c.is(":checkbox, :radio, select, :button, :submit"),type=c.attr("type"),evt=d.events[type]||d.events[isInput?(isWidget?'widget':'input'):'def'];if(!effect){throw"Nonexistent effect \""+d.effect+"\"";}evt=evt.split(/,\s*/);if(evt.length!=2){throw"Tooltip: bad events configuration for "+type;}c.bind(evt[0],function(e){clearTimeout(timer);if(d.predelay){pretimer=setTimeout(function(){f.show(e)},d.predelay)}else{f.show(e)}}).bind(evt[1],function(e){clearTimeout(pretimer);if(d.delay){timer=setTimeout(function(){f.hide(e)},d.delay)}else{f.hide(e)}});if(title&&d.cancelDefault){c.removeAttr("title");c.data("title",title)}$.extend(f,{show:function(e){if(!tip){if(tipAttr){tip=$(tipAttr)}else if(d.tip){tip=$(d.tip).eq(0)}else if(title){tip=$(d.layout).addClass(d.tipClass).appendTo(document.body).hide().append(title)}else{tip=c.next();if(!tip.length){tip=c.parent().next()}}if(!tip.length){throw"Cannot find tooltip for "+c;}}if(f.isShown()){return f}tip.stop(true,true);var a=getPosition(c,tip,d);if(d.tip){tip.html(c.data("title"))}e=e||$.Event();e.type="onBeforeShow";fire.trigger(e,[a]);if($.browser.mozilla){}else{if(e.isDefaultPrevented()){return f}}a=getPosition(c,tip,d);tip.css({position:'absolute',top:a.top,left:a.left});shown=true;effect[0].call(f,function(){e.type="onShow";shown='full';fire.trigger(e)});var b=d.events.tooltip.split(/,\s*/);if(!tip.data("__set")){tip.bind(b[0],function(){clearTimeout(timer);clearTimeout(pretimer)});if(b[1]&&!c.is("input:not(:checkbox, :radio), textarea")){tip.bind(b[1],function(e){if(e.relatedTarget!=c[0]){c.trigger(evt[1].split(" ")[0])}})}tip.data("__set",true)}return f},hide:function(e){if(!tip||!f.isShown()){return f}e=e||$.Event();e.type="onBeforeHide";fire.trigger(e);if($.browser.mozilla){}else{if(e.isDefaultPrevented()){return}}shown=false;g[d.effect][1].call(f,function(){e.type="onHide";fire.trigger(e)});return f},isShown:function(a){return a?shown=='full':shown},getConf:function(){return d},getTip:function(){return tip},getTrigger:function(){return c}});$.each("onHide,onBeforeShow,onShow,onBeforeHide".split(","),function(i,b){if($.isFunction(d[b])){$(f).bind(b,d[b])}f[b]=function(a){if(a){$(f).bind(b,a)}return f}})}$.fn.tooltip=function(a){var b=this.data("tooltip");if(b){return b}a=$.extend(true,{},$.tools.tooltip.conf,a);if(typeof a.position=='string'){a.position=a.position.split(/,?\s/)}this.each(function(){b=new Tooltip($(this),a);$(this).data("tooltip",b)});return a.api?b:this}})(jQuery);

(function(d){var i=d.tools.tooltip;d.extend(i.conf,{direction:"up",bounce:false,slideOffset:10,slideInSpeed:200,slideOutSpeed:200,slideFade:!d.browser.msie});var e={up:["-","top"],down:["+","top"],left:["-","left"],right:["+","left"]};i.addEffect("slide",function(g){var a=this.getConf(),f=this.getTip(),b=a.slideFade?{opacity:a.opacity}:{},c=e[a.direction]||e.up;b[c[1]]=c[0]+"="+a.slideOffset;a.slideFade&&f.css({opacity:0});f.show().animate(b,a.slideInSpeed,g)},function(g){var a=this.getConf(),f=a.slideOffset,b=a.slideFade?{opacity:0}:{},c=e[a.direction]||e.up,h=""+c[0];if(a.bounce)h=h=="+"?"-":"+";b[c[1]]=h+"="+f;this.getTip().animate(b,a.slideOutSpeed,function(){d(this).hide();g.call()})})})(jQuery);

(function(g){function j(a){var c=g(window),d=c.width()+c.scrollLeft(),h=c.height()+c.scrollTop();return[a.offset().top<=c.scrollTop(),d<=a.offset().left+a.width(),h<=a.offset().top+a.height(),c.scrollLeft()>=a.offset().left]}function k(a){for(var c=a.length;c--;)if(a[c])return false;return true}var i=g.tools.tooltip;i.dynamic={conf:{classNames:"top right bottom left"}};g.fn.dynamic=function(a){if(typeof a=="number")a={speed:a};a=g.extend({},i.dynamic.conf,a);var c=a.classNames.split(/\s/),d;this.each(function(){var h=g(this).tooltip().onBeforeShow(function(e,f){e=this.getTip();var b=this.getConf();d||(d=[b.position[0],b.position[1],b.offset[0],b.offset[1],g.extend({},b)]);g.extend(b,d[4]);b.position=[d[0],d[1]];b.offset=[d[2],d[3]];e.css({visibility:"hidden",position:"absolute",top:f.top,left:f.left}).show();f=j(e);if(!k(f)){if(f[2]){g.extend(b,a.top);b.position[0]="top";e.addClass(c[0])}if(f[3]){g.extend(b,a.right);b.position[1]="right";e.addClass(c[1])}if(f[0]){g.extend(b,a.bottom);b.position[0]="bottom";e.addClass(c[2])}if(f[1]){g.extend(b,a.left);b.position[1]="left";e.addClass(c[3])}if(f[0]||f[2])b.offset[0]*=-1;if(f[1]||f[3])b.offset[1]*=-1}e.css({visibility:"visible"}).hide()});h.onBeforeShow(function(){var e=this.getConf();this.getTip();setTimeout(function(){e.position=[d[0],d[1]];e.offset=[d[2],d[3]]},0)});h.onHide(function(){var e=this.getTip();e.removeClass(a.classNames)});ret=h});return a.api?ret:this}})(jQuery);

jQuery(document).ready(function(){
	jQuery('.link_tooltip').tooltip({
		effect:'slide',
		direction:'up',
		slideOffset:15,
		slideInSpeed:300,
		slideOutSpeed:300,
		position:'bottom center'
	});
});



/* Social Icons Scripts */
(function($){$.fn.socicons=function(c){var d={icons:'digg,stumbleupon,delicious,facebook,yahoo',imagesurl:'images/',imageformat:'png',light:true,targetblank:true,shorturl:''};var e=$.extend({},d,c);var f=this;var g=e.targetblank?'target="_blank"':'';var h=e.icons.split(',');for(key in h){var j=h[key];var k=socformat[h[key]];if(k!=undefined){k=k.replace('{TITLE}',urlencode(socicons_title()));k=k.replace('{URL}',urlencode(socicons_url()));k=k.replace('{SHORTURL}',urlencode(socicons_shorturl()));k=k.replace('{KEYWORDS}',urlencode(socicons_metawords()));k=k.replace('{DESCRIPTION}',urlencode(socicons_metadescript()));var l='<a '+g+' href="'+k+'" class="socicons_icon" title="'+j+'"><img src="'+e.imagesurl+j+'.'+e.imageformat+'" alt="'+j+'" /></a>';this.append(l)}}if(e.light){this.find('.socicons_icon').bind('mouseover',function(){$(this).siblings().stop().animate({'opacity':0.3},500)});this.find('.socicons_icon').bind('mouseout',function(){$(this).siblings().stop().animate({'opacity':1},500)})}var m;function socicons_metawords(){if(n==undefined){metaCollection=document.getElementsByTagName('meta');for(i=0;i<metaCollection.length;i++){nameAttribute=metaCollection[i].name.search(/keywords/);if(nameAttribute!=-1){m=metaCollection[i].content;return m}}}else{return m}}var n;function socicons_metadescript(){if(n==undefined){metaCollection=document.getElementsByTagName('meta');for(i=0;i<metaCollection.length;i++){nameAttribute=metaCollection[i].name.search(/description/);if(nameAttribute!=-1){n=metaCollection[i].content;return n}}}else{return n}}function socicons_title(){return document.title}function socicons_url(){var a=document.location.href;return a}function socicons_shorturl(){if(e.shorturl==''){return socicons_url()}else{return e.shorturl}}function urlencode(a){if(a==undefined){return''}return a.replace(/\s/g,'%20').replace('+','%2B').replace('/%20/g','+').replace('*','%2A').replace('/','%2F').replace('@','%40')}function light(a,b){if(b){a.style.opacity=1;a.childNodes[0].style.filter='progid:DXImageTransform.Microsoft.Alpha(opacity=100);'}else{a.style.opacity=light_opacity/100;a.style.filter='alpha(opacity=20)';a.childNodes[0].style.filter='progid:DXImageTransform.Microsoft.Alpha(opacity='+light_opacity+');'}}return this}})(jQuery);

var socformat = Array();
socformat['nujij'] = 'http://nujij.nl/jij.lynkx?t={TITLE}&u={URL}&b={DESCRIPTION}'
socformat['ekudos'] = 'http://www.ekudos.nl/artikel/nieuw?url={URL}&title={TITLE}&desc={DESCRIPTION}';
socformat['digg'] = 'http://digg.com/submit?phase=2&url={URL}&title={TITLE}';
socformat['linkedin'] = 'http://www.linkedin.com/shareArticle?mini=true&url={URL}&title={TITLE}&summary={DESCRIPTION}&source=';
socformat['sphere'] = 'http://www.sphere.com/search?q=sphereit:{URL}';
socformat['technorati'] = 'http://www.technorati.com/faves?add={URL}';
socformat['delicious'] = 'http://del.icio.us/post?url={URL}&title={TITLE}';
socformat['furl'] = 'http://furl.net/storeIt.jsp?u={URL}&t={TITLE}';
socformat['netscape'] = 'http://www.netscape.com/submit/?U={URL}&T={TITLE}';
socformat['yahoo'] = 'http://myweb2.search.yahoo.com/myresults/bookmarklet?u={URL}&t={TITLE}';
socformat['google'] = 'http://www.google.com/bookmarks/mark?op=edit&bkmk={URL}&title={TITLE}';
socformat['newsvine'] = 'http://www.newsvine.com/_wine/save?u={URL}&h={TITLE}';
socformat['reddit'] = 'http://reddit.com/submit?url={URL}&title={TITLE}';
socformat['blogmarks'] = 'http://blogmarks.net/my/new.php?mini=1&url={URL}&title={TITLE}';
socformat['magnolia'] = 'http://ma.gnolia.com/bookmarklet/add?url={URL}&title={TITLE}';
socformat['live'] = 'https://favorites.live.com/quickadd.aspx?marklet=1&mkt=en-us&url={URL}&title={TITLE}&top=1';
socformat['tailrank'] = 'http://tailrank.com/share/?link_href={URL}&title={TITLE}';
socformat['facebook'] = 'http://www.facebook.com/share.php?u={URL}';
socformat['twitter'] = 'http://twitter.com/?status={TITLE}%20-%20{SHORTURL}';
socformat['stumbleupon'] = 'http://www.stumbleupon.com/submit?url={URL}&title={TITLE}';
socformat['bligg'] = 'http://www.bligg.nl/submit.php?url={URL}';
socformat['symbaloo'] = 'http://www.symbaloo.com/en/add/url={URL}&title={TITLE}';
socformat['misterwong'] = 'http://www.mister-wong.com/add_url/?bm_url={URL}&bm_title={TITLE}&bm_comment=&bm_tags={KEYWORDS}';
socformat['buzz']	= 'http://www.google.com/reader/link?url={URL}&title={TITLE}&snippet={DESCRIPTION}&srcURL={URL}&srcTitle={TITLE}';
socformat['myspace'] = 'http://www.myspace.com/Modules/PostTo/Pages/?u={URL}';
socformat['mail']	= 'mailto:to@email.com?SUBJECT={TITLE}&BODY={DESCRIPTION}-{URL}';

jQuery(document).ready(function(){ 
	jQuery('.social').socicons({
		icons:'nujij,linkedin,ekudos,digg,sphere,technorati,delicious,furl,netscape,yahoo,google,newsvine,reddit,blogmarks,magnolia,live,tailrank,facebook,twitter,stumbleupon,bligg,symbaloo,misterwong,mail',
		imagesurl:'images/socicons/'
	});
});

jQuery(document).ready(function(){
	jQuery('.share_posts a.button').toggle(function(){
		jQuery(this).parent().find('.social').show('slow');
		return false;
	}, function(){
		jQuery(this).parent().find('.social').hide('slow');
		return false;
	});
});



/* Theme Scripts */
jQuery(document).ready(function(){
	if (jQuery('body').hasClass('horizon') && jQuery('body').hasClass('simple')){
		jQuery(window).scroll(function(){
			if (jQuery('html').scrollTop() > 20){
				jQuery('.header_wrap').css({backgroundColor:'rgba(0, 0, 0, 1)'});
			} else {
				jQuery('.header_wrap').css({backgroundColor:'rgba(0, 0, 0, 0.8)'});
			}
		});
	}
	
	jQuery('.standard .header_arrow').live('click', function(){
		showHideContent();
		
		return false;
	});
	
	jQuery('.vertical .header_arrow').live('click', function(){
		showHideContent();
		
		return false;
	});
	
	jQuery('.horizon .header_arrow').live('click', function(){
		showHideContent();
		
		return false;
	});
});



/* Show/Hide Content */
function showHideContent(){
	if (jQuery('body').hasClass('standard')){
		if (jQuery('.standard .header_wrap').css('left') == '10px'){
			jQuery('.standard .header_wrap').animate({left:'-242px'}, 700, 'easeInQuint', function(){
				jQuery('.standard .header_arrow').addClass('hidden').css({left:'85px'}).animate({left:'155px'}, 300, 'easeInQuint');
			});
			jQuery('.standard #middle').css({position:'fixed'}).animate({left:'-1000px'}, 700, 'easeInQuint');
		} else {
			jQuery('.standard .header_arrow').animate({left:'85px'}, 300, 'easeOutQuint', function(){
				jQuery(this).removeClass('hidden').css({left:0});
				jQuery('.standard .header_wrap').animate({left:'10px'}, 700, 'easeOutQuint');
				jQuery('.standard #middle').animate({left:'262px'}, 700, 'easeOutQuint', function(){
					jQuery(this).css({position:'relative'});
				});
			});
		}
	} else if (jQuery('body').hasClass('vertical')){
		if (jQuery('.vertical .header_wrap').css('top') == '0px'){
			jQuery('.vertical .header_wrap').animate({top:'-1600px'}, 700, 'easeInQuint', function(){
				jQuery('.vertical .header_arrow').addClass('hidden');
				jQuery('.vertical .header_arrow_wrap').css({position:'absolute', top:'1600px'});
				
				jQuery('.vertical .header_arrow').css({top:'-70px'}).animate({top:0}, 300, 'easeInQuint');
			});
			jQuery('.vertical #middle').animate({top:'1600px'}, 700, 'easeInQuint', function(){
				jQuery(this).css({position:'fixed'});
			});
		} else {
			jQuery('.vertical .header_arrow').animate({top:'-70px'}, 300, 'easeOutQuint', function(){
				jQuery(this).removeClass('hidden').css({top:0});
				jQuery('.vertical .header_arrow_wrap').css({position:'relative', top:0});
				
				jQuery('.vertical .header_wrap').animate({top:0}, 700, 'easeOutQuint');
				jQuery('.vertical #middle').css({position:'relative'}).animate({top:0}, 700, 'easeOutQuint');
			});
		}
	} else if (jQuery('body').hasClass('horizon')){
		if (jQuery('.horizon .header_wrap').css('top') == '0px'){
			jQuery('.horizon .header_wrap').animate({top:'-500px'}, 700, 'easeInQuint', function(){
				jQuery('.horizon .header_arrow').addClass('hidden').css({top:'430px'}).animate({top:'500px'}, 300, 'easeInQuint');
			});
			jQuery('.horizon #middle').css({position:'fixed'}).animate({top:'1600px'}, 700, 'easeInQuint');
		} else {
			jQuery('.horizon .header_arrow').animate({top:'430px'}, 300, 'easeOutQuint', function(){
				jQuery(this).removeClass('hidden').css({top:'14px'});
				
				jQuery('.horizon .header_wrap').animate({top:0}, 700, 'easeOutQuint');
				jQuery('.horizon #middle').animate({top:parseInt(jQuery('.horizon .header_wrap').height()+16)+'px'}, 700, 'easeOutQuint', function(){
					jQuery(this).css({position:'relative'});
				});
			});
		}
	}
}



/* Scroll Top */
jQuery(document).ready(function(){
	jQuery('.divider a').click(function(){
		jQuery('html, body').animate({scrollTop:0}, 'slow');
		return false;
	});
});



/* Toggle */
jQuery(document).ready(function(){
	jQuery('.togg a.tog').click(function(i){
		var dropDown = jQuery(this).parent().find('.tab_content');
		jQuery(this).parent().find('.tab_content').not(dropDown).slideUp();
		if (jQuery(this).hasClass('current')){
			jQuery(this).removeClass('current');
		} else { 
			jQuery(this).addClass('current');
		}
		dropDown.stop(false,true).slideToggle().css({display:'block'});
		i.preventDefault();
	})
});



/* Accordion */
jQuery(document).ready(function(){
	jQuery('.accordion a.tog').click(function(i){
		if (jQuery(this).hasClass('current')){ 
			jQuery(this).removeClass('current');
		} else { 
			jQuery(this).parent().parent().find('.tog').removeClass('current');
			jQuery(this).addClass('current');
		}
		var dropDown = jQuery(this).parent().find('.tab_content');
		jQuery(this).parent().parent().find('.tab_content').not(dropDown).slideUp();
		dropDown.stop(false,true).slideToggle().css({display:'block'});
		i.preventDefault();
	})
});



/* Tabs */
jQuery(document).ready(function(){
	jQuery('.tab ul.tabs li:first-child a').addClass('current');
	jQuery('.tab .tab_content div.tabs_tab:first-child').show();
	jQuery('.tab ul.tabs li a').click(function(e){
		$tab = jQuery(this).parent().parent().parent();
		$tab.find('ul.tabs').find('a').removeClass('current');
		jQuery(this).addClass('current');
		var $index = jQuery(this).parent().index();
		$tab.find('.tab_content').find('div.tabs_tab').not('div.tabs_tab:eq('+$index+')').slideUp();
		$tab.find('.tab_content').find('div.tabs_tab:eq('+$index+')').slideDown();
		e.preventDefault();
	})
});



/* Pretty Photo Lighbox */
jQuery(document).ready(function(){
	jQuery('a[rel^="prettyPhoto"]').prettyPhoto({animationSpeed:'normal', deeplinking:false, social_tools:false});
});



/* Form Send */
function submitform(){
    document.forms['commentform'].submit();
	return false;
};



/* Contact Form */
function checkemail(emailaddress){
	var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
	return pattern.test(emailaddress);
}

jQuery(document).ready(function(){ 
	jQuery('#contactform a#formsend').click(function(){
		var $name 	= jQuery('#name').val();
		var $email 	= jQuery('#email').val();
		var $subject = jQuery('#subject').val();
		var $url = jQuery('#url').val();
		var $message = jQuery('#message').val();
		var $contactemail = jQuery('#contactemail').val();
		var $contacturl = jQuery('#contacturl').val();
		var $mywebsite = jQuery('#contactwebsite').val();
		
		if ($name != '' && $name.length < 3){ $nameshort = true; } else { $nameshort = false; }
		if ($name != '' && $name.length > 30){ $namelong = true; } else { $namelong = false; }
		if ($email != '' && checkemail($email)){ $emailerror = true; } else { $emailerror = false; }
		if ($subject != '' && $subject.length < 3){ $subjectshort = true; } else { $subjectshort = false; }
		if ($subject != '' && $subject.length > 100){ $subjectlong = true; } else { $subjectlong = false; }
		if ($url == ''){ $url = 'none'; }
		if ($message != '' && $message.length < 3){ $messageshort = true; } else { $messageshort = false; }
		
		jQuery('#contactform .loading').animate({opacity: 1}, 250);
		
		if ($name != '' && $nameshort != true && $namelong != true && $email != '' && $emailerror != false && $subject != '' && $subjectshort != true && $subjectlong != true && $message != '' && $messageshort != true && $contactemail != '' && $contacturl != '' && $mywebsite != ''){
			jQuery.post($contacturl, 
				{type:'form', contactemail:$contactemail, name:$name, email:$email, subject:$subject, website:$url, message:$message, mywebsite:$mywebsite}, 
				function(data){
					jQuery('#contactform .loading').animate({opacity: 0}, 250);
					jQuery('.entry div.contform').fadeOut('slow');
					jQuery('#name, #subject, #url, #email, #message').val('');
					jQuery('#contactform div.form_info div.form_error').hide();
					jQuery('.entry .box').hide();
					jQuery('.entry .info_box').fadeIn('fast');
					jQuery('html, body').animate({scrollTop:0}, 'slow');
					jQuery('.entry .info_box').delay(5000).fadeOut(1000, function(){ 
						jQuery('.entry div.contform').fadeIn('slow');
					});
				}
			);
			
			return false;
		} else {
			jQuery('#contactform .loading').animate({opacity: 0}, 250);
			jQuery('.entry .box').hide();
			jQuery('.entry .error_box').fadeIn('fast');
			jQuery('html, body').animate({scrollTop:0}, 'slow');
			jQuery('.entry .error_box').delay(5000).fadeOut('slow');
			
			if ($name == ''){ 
				jQuery('#name').parent().find('div.form_error').hide(); 
				jQuery('#name').parent().find('div.defaulterror').show(); 
			} else if ($nameshort == true){ 
				jQuery('#name').parent().find('div.form_error').hide(); 
				jQuery('#name').parent().find('div.shorterror').show(); 
			} else if ($namelong == true){ 
				jQuery('#name').parent().find('div.form_error').hide(); 
				jQuery('#name').parent().find('div.longerror').show(); 
			} else { 
				jQuery('#name').parent().find('div.form_error').hide();
			}
			
			if ($email == ''){ 
				jQuery('#email').parent().find('div.form_error').hide(); 
				jQuery('#email').parent().find('div.defaulterror').show();
			} else if ($emailerror == false){ 
				jQuery('#email').parent().find('div.form_error').hide(); 
				jQuery('#email').parent().find('div.invaliderror').show();
			} else { 
				jQuery('#email').parent().find('div.form_error').hide();
			}
			
			if ($subject == ''){ 
				jQuery('#subject').parent().find('div.form_error').hide(); 
				jQuery('#subject').parent().find('div.defaulterror').show(); 
			} else if ($subjectshort == true){ 
				jQuery('#subject').parent().find('div.form_error').hide(); 
				jQuery('#subject').parent().find('div.shorterror').show(); 
			} else if ($subjectlong == true){ 
				jQuery('#subject').parent().find('div.form_error').hide(); 
				jQuery('#subject').parent().find('div.longerror').show(); 
			} else { 
				jQuery('#subject').parent().find('div.form_error').hide(); 
			}
			
			if ($message == ''){ 
				jQuery('#message').parent().find('div.form_error').hide(); 
				jQuery('#message').parent().find('div.defaulterror').show(); 
			} else if ($messageshort == true){ 
				jQuery('#message').parent().find('div.form_error').hide();
				jQuery('#message').parent().find('div.shorterror').show(); 
			} else { 
				jQuery('#message').parent().find('div.form_error').hide();
			}
			
			return false;
		}
	});
});



jQuery(document).ready(function(){
	if (jQuery.browser.msie && jQuery.browser.version < 8){
		jQuery('blockquote').each(function(i){
			jQuery(this).wrap('<div class="blockquote_container" />');
			jQuery(this).before('<span class="blockquote_img quotation" />');
			jQuery(this).parent().find('.blockquote_img').html('&ldquo;');
		});	// Blockquote
	}
});
